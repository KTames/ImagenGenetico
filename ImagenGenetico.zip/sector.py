#!encoding=utf-8
from color import Color, getColores
import random
from square import Square

class Sector:

    def __init__(self, logicX, logicY, minX, minY, maxX, maxY):
        self.logicX = logicX
        self.logicY = logicY
        self.minX = minX
        self.maxX = maxX
        self.minY = minY
        self.maxY = maxY
        self.probabilidad = 1
        self.points = []
        self._colors = getColores()
        self.generations = [[]]
        self.size = maxX - minX

    def getColors(self):
        return self._colors

    def calculateColors(self):
        countPoints = len(self.points)
        if countPoints == 0:
            self._colors["white"].setProbability(1)
        else:
            qcolors = 0

            pointsToEvaluate = int(
                countPoints * (1. / 3.)
            )if countPoints > 500 else countPoints

            pointsToEvaluate = pointsToEvaluate if pointsToEvaluate < 500 else 500

            for pointIndex in range(0, pointsToEvaluate):
                rand = random.randint(0, countPoints - 1)

                point = self.points[rand]
                hls = Color.rgb_to_hls(point[0], point[1], point[2])

                for key, color in self._colors.items():
                    if color.matches(hls):
                        qcolors += 1
                        self._colors[key].incrementCount(point)
                        break

            for key, color in self._colors.items():
                self._colors[key].setProbability(color.qPoints / qcolors)

        self._createFirstGeneration()

    def _createFirstGeneration(self):
        for index in range(0, 2):
            rand = random.randint(0, 100) / 100
            selectedKey = ""

            for key, color in self._colors.items():
                selectedKey = key
                rand -= color.probability
                if rand <= 0:
                    break
                
            selectedColor = self._colors[selectedKey]

            h = random.randint(int(selectedColor.minH * 100), int(selectedColor.maxH * 100)) / 100
            l = random.randint(int(selectedColor.minL * 100), int(selectedColor.maxL * 100)) / 100
            s = random.randint(25, 75) / 100

            r, g, b = Color.hls_to_rgb(h, l, s)

            self.generations[0].append(Square((r, g, b), (h, s, l), selectedKey, self.size / 2))
