class Genetico:

    def __init__(self, sectores):
        self.sectores = sectores