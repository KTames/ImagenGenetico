// const svg = document.getElementById("svg");
        // const container = document.getElementById("container");

        // svg.style.transitionDuration = "1s";

        // const cantSteps = container.clientWidth;
        // const runningTimeInMilliseconds = 4000;
        // const sleepTimeInMilliseconds = 5;

        // const advancePerStep = container.clientWidth / runningTimeInMilliseconds * sleepTimeInMilliseconds;
        // const maxLimit = container.clientWidth - svg.clientWidth;
        // let paused = false;

        // let count = 0;
        // function show() {
        //     if (!paused) {
        //         svg.style.marginLeft = count;
        //         count += advancePerStep;
        //         if (count <= maxLimit) {
        //             setTimeout(show, sleepTimeInMilliseconds);
        //         }
        //         else {
        //             if (!paused)
        //                 count = 0;
        //             setTimeout(show, sleepTimeInMilliseconds);
        //         }
        //     } else setTimeout(show, sleepTimeInMilliseconds);
        // }
        // show();
        function triggerPause() {
            // paused = !paused;
            svg.style.marginLeft = "100%";
        }