#!encoding=utf-8
class Square:
    def __init__(self, rgbColor, hslColor, colorType, size):
        self.rgbColor = rgbColor
        self.hslColor = hslColor
        self.colorType = colorType
        self.size = size