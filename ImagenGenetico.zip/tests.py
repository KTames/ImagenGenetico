#!encoding=utf-8
from probabilista import Probabilista
from imagen import Imagen
from genetico import Genetico
from color import Color
import colorsys
import sys

# output = [
#     '<!DOCTYPE html><html lang="en"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0"><meta http-equiv="X-UA-Compatible" content="ie=edge"><title>Output</title><style>* {padding: 0;margin: 0;font-family: Arial, Helvetica, sans-serif}body {background-color: #111;}input[type=number] {padding: 5px;width: 300px;font-size: 15px;color: whitesmoke;background-color: #353535;}#container {display: block;border: 1px solid black;width: 1200px;height: 200px;margin-left: calc(50vw - 600px);overflow: hidden;background-color: #fafafa;}svg {width: 200px;height: 200px;margin: auto;}table {width: 1200px;border-collapse: collapse;margin: 20px calc(50vw - 600px);}td {padding: 1rem;width: 50%;}td:first-child {text-align: right;color: white;}button {width: 100%;border-radius: 20px;border: 0;box-shadow: 0 0 5px;padding: 10px;user-select: none;}</style></head><body><div><table><tr><td><label for="iNumber">Tiempo de animación (segundos)</label></td><td><input type="number" name="iNumber" id="iNumber" value="2.0"></td></tr><tr><td colspan="2"><button id="btn">Play</button></td></tr></table></div><div id="container"><svg id="svg" viewBox="0 0 100 100"style="transition-property: all;transition-timing-function: linear;margin-left: 0;"></svg></div><script>const svg = document.getElementById("svg");const container = document.getElementById("container");const button = document.getElementById("btn");const durationBox = document.getElementById("iNumber");button.onclick = restart;const shapes = [',
#     '"<circle cx=50 cy=50 r=1></circle>","<circle cx=50 cy=50 r=2></circle>","<circle cx=50 cy=50 r=3></circle>","<circle cx=50 cy=50 r=4></circle>","<circle cx=50 cy=50 r=5></circle>","<circle cx=50 cy=50 r=6></circle>","<circle cx=50 cy=50 r=7></circle>","<circle cx=50 cy=50 r=8></circle>","<circle cx=50 cy=50 r=9></circle>","<circle cx=50 cy=50 r=10></circle>",'
#     + '"<circle cx=50 cy=50 r=1></circle>","<circle cx=50 cy=50 r=2></circle>","<circle cx=50 cy=50 r=3></circle>","<circle cx=50 cy=50 r=4></circle>","<circle cx=50 cy=50 r=5></circle>","<circle cx=50 cy=50 r=6></circle>","<circle cx=50 cy=50 r=7></circle>","<circle cx=50 cy=50 r=8></circle>","<circle cx=50 cy=50 r=9></circle>","<circle cx=50 cy=50 r=10></circle>",'
#     + '"<circle cx=50 cy=50 r=1></circle>","<circle cx=50 cy=50 r=2></circle>","<circle cx=50 cy=50 r=3></circle>","<circle cx=50 cy=50 r=4></circle>","<circle cx=50 cy=50 r=5></circle>","<circle cx=50 cy=50 r=6></circle>","<circle cx=50 cy=50 r=7></circle>","<circle cx=50 cy=50 r=8></circle>","<circle cx=50 cy=50 r=9></circle>","<circle cx=50 cy=50 r=10></circle>",'
#     + '"<circle cx=50 cy=50 r=1></circle>","<circle cx=50 cy=50 r=2></circle>","<circle cx=50 cy=50 r=3></circle>","<circle cx=50 cy=50 r=4></circle>","<circle cx=50 cy=50 r=5></circle>","<circle cx=50 cy=50 r=6></circle>","<circle cx=50 cy=50 r=7></circle>","<circle cx=50 cy=50 r=8></circle>","<circle cx=50 cy=50 r=9></circle>","<circle cx=50 cy=50 r=10></circle>",'
#     + '"<circle cx=50 cy=50 r=1></circle>","<circle cx=50 cy=50 r=2></circle>","<circle cx=50 cy=50 r=3></circle>","<circle cx=50 cy=50 r=4></circle>","<circle cx=50 cy=50 r=5></circle>","<circle cx=50 cy=50 r=6></circle>","<circle cx=50 cy=50 r=7></circle>","<circle cx=50 cy=50 r=8></circle>","<circle cx=50 cy=50 r=9></circle>","<circle cx=50 cy=50 r=10></circle>",'
#     ,
#     '];let duration = parseFloat(durationBox.value) * 1000;let stepSleep = 0;function restart() {svg.innerHTML = "";duration = parseFloat(durationBox.value) * 1000;stepSleep = duration / shapes.length;button.innerHTML = "Replay";svg.style.transitionDuration = "0s";svg.style.marginLeft = "0";setTimeout(play, 100);}function play() {svg.style.transitionDuration = duration + "ms";svg.style.marginLeft = (container.clientWidth - svg.clientWidth) + "px";animate();}function animate(index = 0) {if (index < shapes.length) {svg.innerHTML = shapes[index];setTimeout(function() {animate(index + 1)}, stepSleep);}}</script></body></html>'
# ]

# file = open("output.html", "w")
# file.truncate()
# file.write(output[0] + output[1] + output[2])
# file.close()
if __name__ == "__main__":
    import multiprocessing

    multiprocessing.freeze_support()

    columnas = 40
    filas = 40
    imagen = Imagen("imgs/imagen.jpg")
    probabilista = Probabilista(imagen, filas, columnas)
    sectores = probabilista.elegirSamples()

    imagen.drawImagenConSalida(sectores)

    index = 0
    for y in range(0, filas):
        for x in range(0, columnas):
            i = sectores[index]
            index += 1
            strings = []
            for k, c in i.getColors().items():
                if (c.probability > 0):
                    strings.append(k.center(20) + str(c.probability))

            if not(len(strings) == 1 and "white" in strings[0]):
                print(str(" (" + str(x) + ", " + str(y) + ") ").center(40, '#'))
                for s in strings:
                    print(s)
                print("\n")

# genetico = Genetico(sectores);

# def threadFunc(index):
#     isPrime = True
#     for i in range(index, 2, -1):
#         for j in range(index -1, 2, -1):
#             if i % j != 0:
#                 isPrime = False
#     print(index, "es primo" if isPrime else "no es primo")
#     return isPrime


